const daftarvip = (prefix) => { 
	return `
	
FREE Tinggal bilang ke owner (wa.me/6289699715959)
cm tnggal vn -Kamu ganteng `
}
exports.daftarvip = daftarvip