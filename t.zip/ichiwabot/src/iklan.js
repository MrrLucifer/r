const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
║
║BELOM ADA IKLAN!
║
╚═〘  Lucifer BOT 〙
`
}
exports.iklan = iklan